<?php

namespace App\Http\Controllers;
use App\Models\Tasks;

use Illuminate\Http\Request;

class TasksController extends Controller
{
    public function index(){
        $tasks= Tasks::all();
        $data= compact('tasks');
        return view('index')->with($data);
    }

    public function add(Request $request){
        $task= $request['task'];        
        $taskData= $request->validate([
            'task'=>'required',            
        ]);
        $newtask= new Tasks;
        $newtask->task = $task;
        $newtask->status= "";
        $newtask->save();

        return response()->json(['status'=>true, 'message'=>'Task Added Succesfully']);
    }

    public function delete($id){
        $task= Tasks::find($id);
        if($task){
            $task->delete();
            return response()->json(['status'=>true,'message'=>'Task deleted succesfuly']);
        }else{
            return response()->json(['status'=>false,'message'=>'Invalid Id. Task not found']);
        }
    }
}
