<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TasksController;

Route::get('/', [TasksController::class,'index']);

Route::post('/task/add',[TasksController::class,'add']);
Route::delete('/task/delete/{id}',[TasksController::class,'delete']);