@extends('layouts.main')

@section('main-section')
    <div class="layouts">
        <div class="container">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-primary">PHP - Simple To Do List</h5>
                        <hr />
                        <div class="row addtaskInput">
                            <form class="form-group">
                                <div class="col-12 col-md-8 d-flex flex-column flex-md-row">
                                    <input type="text" class="form-control me-2" id="task" placeholder="Enter task"
                                        autofocus>
                                    <input type="submit" class="btn btn-primary me-1" value="Add Task">
                                </div>
                            </form>
                        </div>
                        <div class="table-responsive mt-2">
                            <table class="table">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Task</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                                @php
                                    $i = 1;
                                @endphp
                                @if ($tasks)
                                    <input type="number" id="totalCount" value="{{ $tasks->count() }}" hidden />
                                    @foreach ($tasks as $task)
                                        <tr>
                                            <td scope="row">{{ $i }}</td>
                                            <td>{{ $task->task }}</td>
                                            <td>{{ $task->status }}</td>
                                            <td>
                                                <div class="d-flex">
                                                    <i
                                                        class="bi bi-check2-circle btn btn-success btn-sm me-2">
                                                    </i>
                                                    <i 
                                                        class="bi bi-x-lg text-danger btn btn-sm btn-danger text-white deleteBtn"
                                                        data-id={{ $task->id }}
                                                        >
                                                    </i>
                                                </div>
                                            </td>
                                        </tr>
                                        @php
                                            $i++;
                                        @endphp
                                    @endforeach
                                @endif
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {            
            let lastRow= $('table tr:last');
            let sn= lastRow.find('td:eq(0)').text();
            sn++;
            $(".addtaskInput form").on('submit', function(e) {
                e.preventDefault();
                let table = $("table");
                let task = $("#task").val();
                let status = "";
                let buttons = ` <div class="d-flex">                                            
                                    <i class="bi bi-check2-circle btn btn-success btn-sm me-2"></i>
                                    <i class="bi bi-x-lg text-danger btn btn-sm btn-danger text-white deleteBtn"></i>
                                </div>`;

                let tableRow = `<tr>
                                    <td>${sn++}</td>
                                    <td>${task}</td>
                                    <td>${status}</td>
                                    <td>${buttons}</td>
                               </tr>`;
                $.ajax({
                    url: '/task/add',
                    type: 'post',
                    data: {
                        task: task,
                        _token: $("meta[name='csrf-token']").attr('content')
                    },
                    success: function(data) {
                        if(data.status){
                            table.append(tableRow);
                            $("#task").val('');
                        }else{
                            console.log("Con't Delete, Somthing Went Wrong");
                        }                        
                    }
                });

            });

            $(".deleteBtn").on('click', function() {
                let selectedRow = $(this).closest("tr");
                let taskId= $(this).data('id');
                if (confirm("Do You want to delete this task ??")) {
                    $.ajax({
                        url: '/task/delete/'+taskId,
                        type: 'delete',
                        headers:{
                            'X-CSRF-TOKEN': $("meta[name='csrf-token']").attr("content")
                        },
                        dataType:'json',
                        success: function(data) {
                            if(data.status){
                                selectedRow.remove();                                
                            }else{
                                console.log("Can't Delete");
                            }
                    }
                });                    
                }
                console.log(taskId);
            })
        })
    </script>
@endsection
